import './App.css';
import ListProducts from "./components/ListProducts";

function App() {
  return (
    <div className="App">
      <ListProducts/>
    </div>
  );
}

export default App;
